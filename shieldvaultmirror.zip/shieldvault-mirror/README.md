# ShieldVault

**Catches secrets and regret before they leave your browser.**

ShieldVault is a Chrome extension that blocks API keys, passwords, and private
data from slipping into AI chats — and gives you a calm beat before you post
something you can't take back. Everything runs on your machine. Your content is
never stored or sent anywhere.

- Website: https://shieldvault.site
- Chrome Web Store: _(link added at launch)_

## Why this repo exists

ShieldVault's entire pitch is that it *can't* betray you: local-only detection,
no telemetry, no analytics, no account, no remote code, and only two
permissions (`activeTab` + `storage`). Claims like that shouldn't require
trust — they should be checkable.

So the source is here. **Read every line.** This repo contains exactly the
files that ship in the extension — nothing more, nothing less (plus this
README and the LICENSE, which are not part of the shipped package).

## Verify that this code is what actually runs in your browser

Don't take our word that the repo matches the store build — check it.

**Option A — compare the packaged release:**

1. Download the release zip attached to the matching version tag of this repo.
2. Hash it:
   ```
   sha256sum shieldvault-1.7.5.zip
   ```
3. Expected (v1.7.5):
   ```
   82ef9ce0ac933d1caed244a1cb588900e64cdf7c4115b7aa7d384f80fbf83549
   ```

**Option B — compare your installed copy, file by file:**

1. Install ShieldVault from the Chrome Web Store.
2. Find your installed copy at
   `<Chrome profile>/Extensions/<extension-id>/<version>/`
   (visit `chrome://version` to locate your profile path).
3. Hash the files and compare against the table below:
   ```
   cd "<that directory>" && find . -type f | sort | xargs sha256sum
   ```

   > Note: the Chrome Web Store may add a `_metadata/` folder with its own
   > verification hashes during publishing — that folder is added by Google,
   > not by us, and is expected. Every file *we* ship is listed below.

### File hashes — v1.7.5

| File | SHA-256 |
| --- | --- |
| `background.js` | `63cfe0158d1bacd500d1cc1750bbc35ba327c5990ee25cd7fefe8431c7be9a87` |
| `content-script.js` | `4cba57c658fff99eed9363d1b72355e2f7e797a34455ed3f992858cdbef24c90` |
| `how-it-works.html` | `7db78502ef9f77c49058af5db05944b54b9f10abc075056d4cc6d599b0aac5e0` |
| `how-it-works.js` | `fa8122c1bd0bc08a0946115416e879bbccd62d568b56736fb422b78e9d5a463f` |
| `icons/icon128.png` | `8572692e6613a98bc121b9b509c28368dc780aae3e3fc9bf489268f89addede3` |
| `icons/icon16.png` | `9378e90dc41dc49b8f2107b607b5ecd6120267f41863a64ce570648eb303b143` |
| `icons/icon32.png` | `2c17a3843100eb025d025a4f9a6cb50898d86048f26407fbb92145ada6e24131` |
| `icons/icon48.png` | `bb17a4547b888427bc51b2330761151553774e10da4b0971b9f6939d93109036` |
| `icons/shieldvault-icon.svg` | `1513d6b995b5e6c5f7aa847edbc3127306ebfc2b3202440348e8725c07d8deee` |
| `manifest.json` | `e97409cdcdb344b62949e4eee963d69ff8787307b0e3954b3671b885fb883716` |
| `onboarding.html` | `dac718c925b64dddbf203669097c54383b4cc9f7c7fc9f5dedb99f531552f721` |
| `onboarding.js` | `fdee1acc1ecfcd85c81d7b93fc11a9fa5db998c1296cbe51a6272bacae1af308` |
| `proofs.css` | `06baa68da5a23857112114ddcba0c6dbc99959907a5418f3dae73de045f2b29e` |
| `proofs.html` | `a120fe59f846177f28e6498e7057e2719c6526ec7b101bcf20885a8829bf576e` |
| `proofs.js` | `537114708b1d5abd49eb6a2af6a9e389472cb8693edf3150946d794eb422214d` |
| `settings.html` | `097f27c3f6c113cdf9b8aaece7d1bb7c28b35916c63964d52bd6dc51ae6756f2` |
| `settings.js` | `efd0e29abe97947c54b778ea9fc70e8f266cd1ea508ed2bfc4f31178919a9122` |

## What to look for while you read

If you're auditing the privacy claims, these are the load-bearing spots:

- **`manifest.json`** — permissions are `activeTab` and `storage`, nothing
  else. The single `host_permissions` entry (`https://shieldvault.site/*`) is
  used solely for optional Pro license activation.
- **`content-script.js`** — all detection (`DETECTORS`,
  `detectSecretMatches`, `BEHAVIORAL_DETECTORS`) runs in-page.
  `notifyBackground()` is the only thing the content script reports, and it
  sends detector *labels* (e.g. `"OpenAI API Key"`), never matched values.
- **`background.js`** — `proofFromMessage()` defines everything ShieldVault
  persists about an event: timestamp, domain, category, vector, detector
  labels. Metadata only, stored locally.
- **`proofs.js`** — the only network calls in the codebase: license
  activation/validation against `shieldvault.site`, and opening Stripe
  checkout. No page content is ever transmitted.
- **Search the repo** for `fetch(`, `XMLHttpRequest`, `eval`, `new Function`
  — the complete list of network and dynamic-code surface fits on one line.

## Reporting issues

Found a bug, a false positive, or something that contradicts a claim above?
Open an issue — especially the last kind. Security reports:
support@shieldvault.site.

## License

Source-available under the Business Source License — see [LICENSE](LICENSE).
You are welcome to read, audit, and build ShieldVault from source for
verification. Redistribution and competing commercial use are restricted per
the license terms.

---

*Detection without possession.*
