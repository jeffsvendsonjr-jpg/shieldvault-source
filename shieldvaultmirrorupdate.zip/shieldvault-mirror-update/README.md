# ShieldVault

**Catches secrets and regret before they leave your browser.**

ShieldVault is a Chrome extension that blocks API keys, passwords, and private
data from slipping into AI chats — and gives you a calm beat before you post
something you can't take back. Everything runs on your machine. Your content is
never stored or sent anywhere.

- Website: https://shieldvault.site
- Chrome Web Store: _(link added at launch)_

## Why this repo exists

ShieldVault's entire pitch is that it *can't* betray you: local-only detection,
no telemetry, no analytics, no account, no remote code, and only two
permissions (`activeTab` + `storage`). Claims like that shouldn't require
trust — they should be checkable.

So the source is here. **Read every line.** This repo contains exactly the
files that ship in the extension — nothing more, nothing less (plus this
README and the LICENSE, which are not part of the shipped package).

## Verify that this code is what actually runs in your browser

Don't take our word that the repo matches the store build — check it.

**Option A — compare the packaged release:**

1. Download the release zip attached to the matching version tag of this repo.
2. Hash it:
   ```
   sha256sum shieldvault-1.7.5.zip
   ```
3. Expected (v1.7.5):
   ```
   11b5c7c0bb8d56aa0453561e0b429834f64f03f5536f358a90b02995a79de57d
   ```

**Option B — compare your installed copy, file by file:**

1. Install ShieldVault from the Chrome Web Store.
2. Find your installed copy at
   `<Chrome profile>/Extensions/<extension-id>/<version>/`
   (visit `chrome://version` to locate your profile path).
3. Hash the files and compare against the table below:
   ```
   cd "<that directory>" && find . -type f | sort | xargs sha256sum
   ```

   > Note: the Chrome Web Store may add a `_metadata/` folder with its own
   > verification hashes during publishing — that folder is added by Google,
   > not by us, and is expected. Every file *we* ship is listed below.

### File hashes — v1.7.5

| File | SHA-256 |
| --- | --- |
| `background.js` | `b06e575a53741930df2fe501010e1e93f3e0a97713220313fa7985eefee8c506` |
| `content-script.js` | `2ebf4867934b551b545251e62e75d7a8b7fcfb2ea45bb37f5d7524cb0306a89c` |
| `how-it-works.html` | `7db78502ef9f77c49058af5db05944b54b9f10abc075056d4cc6d599b0aac5e0` |
| `how-it-works.js` | `fa8122c1bd0bc08a0946115416e879bbccd62d568b56736fb422b78e9d5a463f` |
| `icons/icon128.png` | `8572692e6613a98bc121b9b509c28368dc780aae3e3fc9bf489268f89addede3` |
| `icons/icon16.png` | `9378e90dc41dc49b8f2107b607b5ecd6120267f41863a64ce570648eb303b143` |
| `icons/icon32.png` | `2c17a3843100eb025d025a4f9a6cb50898d86048f26407fbb92145ada6e24131` |
| `icons/icon48.png` | `bb17a4547b888427bc51b2330761151553774e10da4b0971b9f6939d93109036` |
| `icons/shieldvault-icon.svg` | `1513d6b995b5e6c5f7aa847edbc3127306ebfc2b3202440348e8725c07d8deee` |
| `manifest.json` | `e535f305001a4abceb4e86d818ebb71a18aa82ab0fd562b6564f6dbf48c53c89` |
| `onboarding.html` | `dac718c925b64dddbf203669097c54383b4cc9f7c7fc9f5dedb99f531552f721` |
| `onboarding.js` | `fdee1acc1ecfcd85c81d7b93fc11a9fa5db998c1296cbe51a6272bacae1af308` |
| `proofs.css` | `06baa68da5a23857112114ddcba0c6dbc99959907a5418f3dae73de045f2b29e` |
| `proofs.html` | `61425cfc0649e81d005d47f674930570df29397d07669df3b51e0f6de7b3122e` |
| `proofs.js` | `d5915ca2c55df7220acadc6a58247b8ddec7877f9b63cb309bf1916abce02792` |
| `settings.html` | `097f27c3f6c113cdf9b8aaece7d1bb7c28b35916c63964d52bd6dc51ae6756f2` |
| `settings.js` | `de24fa35b76860b8fbf075fb51708c36644825b4cc3b387babbde7a1f1437774` |

## What to look for while you read

If you're auditing the privacy claims, these are the load-bearing spots:

- **`manifest.json`** — permissions are `activeTab` and `storage`, nothing
  else. The single `host_permissions` entry (`https://shieldvault.site/*`) is
  used solely for optional Pro license activation.
- **`content-script.js`** — all detection (`DETECTORS`,
  `detectSecretMatches`, `BEHAVIORAL_DETECTORS`) runs in-page.
  `notifyBackground()` is the only thing the content script reports, and it
  sends detector *labels* (e.g. `"OpenAI API Key"`), never matched values.
- **`background.js`** — `proofFromMessage()` defines everything ShieldVault
  persists about an event: timestamp, domain, category, vector, detector
  labels. Metadata only, stored locally.
- **`proofs.js`** — the only network calls in the codebase: license
  activation/validation against `shieldvault.site`, and opening Stripe
  checkout. No page content is ever transmitted.
- **Search the repo** for `fetch(`, `XMLHttpRequest`, `eval`, `new Function`
  — the complete list of network and dynamic-code surface fits on one line.

## Reporting issues

Found a bug, a false positive, or something that contradicts a claim above?
Open an issue — especially the last kind. Security reports:
support@shieldvault.site.

## License

Source-available under the Business Source License — see [LICENSE](LICENSE).
You are welcome to read, audit, and build ShieldVault from source for
verification. Competing commercial use is restricted per the license terms.

---

*Detection without possession.*
